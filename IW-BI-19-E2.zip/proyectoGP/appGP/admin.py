from django.contrib import admin
from .models import Proyecto, Tarea, Persona

admin.site.register(Proyecto)
admin.site.register(Tarea)
admin.site.register(Persona)
